# BERBIECLOSET (static)
Plain HTML + Bootstrap 5.3 (CDN) + CSS + JS. Open index.html, or host the folder anywhere (GitHub Pages, Netlify).
- Edit products in assets/js/products.js; header/footer in assets/js/main.js; look in assets/css/style.css.
- TODO: replace assets/img/hero.jpg and assets/img/about.jpg (placeholders) with the originals from the live site, and set a full https URL for og:image once hosted.
