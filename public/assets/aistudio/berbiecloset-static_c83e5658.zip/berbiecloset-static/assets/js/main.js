const WA='2347030107401',IGH='https://www.instagram.com/berbiecloset?dlrf=ODZiajFpN3gyOGZr',TT='https://www.tiktok.com/@berbiecloset?_r=1&_t=ZS-9BEc3LLAMEb';
const $=(s,r=document)=>r.querySelector(s),wa=t=>`https://wa.me/${WA}?text=${encodeURIComponent(t)}`,money=n=>'₦'+n.toLocaleString('en-NG');
const Cart={key:'berbiecloset-cart-v1',read(){try{return JSON.parse(localStorage.getItem(this.key)||'[]')}catch{return[]}},
save(c){try{localStorage.setItem(this.key,JSON.stringify(c))}catch{}Cart.count()},
add(p){const c=this.read(),l=c.find(x=>x.product.id===p.id);l?l.quantity++:c.push({product:p,quantity:1});this.save(c)},
count(){const n=this.read().reduce((s,l)=>s+l.quantity,0),b=$('#bag-count');if(b)b.textContent=n}};
const logo=(c='')=>`<a class="bc-logo-link" href="index.html" aria-label="BERBIECLOSET home"><img class="bc-logo ${c}" src="assets/img/logo.webp" alt="BERBIECLOSET crowned monogram"></a>`;
function layout(){
$('#site-header').innerHTML=`<div class="bc-announcement">A considered wardrobe · Made to make a statement</div>
<header class="bc-header"><nav class="navbar navbar-expand-lg"><div class="container-fluid px-0">${logo()}
<button class="navbar-toggler border-0" data-bs-toggle="collapse" data-bs-target="#nav" aria-label="Menu"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav"><div class="bc-nav mx-lg-auto"><a href="shop.html">Shop</a><a href="about.html">Our story</a><a href="contact.html">Contact</a></div>
<div class="d-flex align-items-lg-center flex-column flex-lg-row gap-3"><a class="bc-social" href="${IGH}" target="_blank" rel="noopener"><strong>@berbiecloset</strong> · IG ↗</a><a class="bc-social" href="${TT}" target="_blank" rel="noopener"><strong>@berbiecloset</strong> · TikTok ↗</a><a class="bc-social" href="${wa('Hello BERBIECLOSET, I have a general enquiry.')}" target="_blank" rel="noopener">WhatsApp ↗</a>
<a class="bc-bag" href="bag.html">Bag (<span id="bag-count">0</span>) ↗</a></div></div></div></nav></header>
${document.body.dataset.page==='home'?'':'<a class="bc-back" href="javascript:history.length>1?history.back():location.href=\'index.html\'">← Back</a>'}`;
$('#site-footer').innerHTML=`<footer class="bc-footer">${logo('')}<p>Style is personal. Make it yours.</p><a class="s" href="contact.html">CONTACT US ↗</a>
<div><a class="s" href="${IGH}" target="_blank" rel="noopener"><strong>@BERBIECLOSET</strong> · INSTAGRAM ↗</a><a class="s" href="${TT}" target="_blank" rel="noopener"><strong>@BERBIECLOSET</strong> · TIKTOK ↗</a></div><span>© ${new Date().getFullYear()} BERBIECLOSET</span></footer>`;Cart.count()}
const priceOf=p=>p.price?money(p.price):'Price on request';
function shop(){$('#grid').innerHTML=PRODUCTS.map(p=>`<article class="bc-card"><a href="product.html?id=${p.id}"><div class="bc-img"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="bc-idx">0${p.id}</span><span class="bc-view">View piece ↗</span></div></a>
<div class="bc-info"><h3>${p.name}</h3><p>${p.note}</p><strong>${priceOf(p)}</strong>${p.sizes?`<p class="mt-2">AVAILABLE SIZES ${p.sizes}</p>`:''}</div></article>`).join('')}
function product(){const p=PRODUCTS.find(x=>x.id==new URLSearchParams(location.search).get('id'));
if(!p){$('#detail').innerHTML='<h1>Piece not found.</h1><a class="bc-btn" href="shop.html">Back to collection ↗</a>';return}
document.title=p.name+' · BERBIECLOSET';
$('#detail').innerHTML=`<div class="bc-split bc-detail"><img src="${p.image}" alt="${p.name}"><div><p class="eyebrow">${p.category} · BERBIECLOSET EDIT</p><h1>${p.name}</h1><p class="muted">${p.note}</p><strong class="price">${priceOf(p)}</strong>
${p.sizes?`<p class="muted">Available sizes: ${p.sizes}</p>`:''}<p class="bc-note text-start m-0 mb-4">${p.price?'Price shown from the Instagram post. Confirm current availability before ordering.':'Contact us on WhatsApp to confirm current availability and price.'}</p>
<div class="d-flex flex-wrap gap-2"><a class="bc-btn" target="_blank" rel="noopener" href="${wa(`Hello BERBIECLOSET, I would like to make an enquiry about the ${p.name}. Is it available? Please share the available sizes and confirm the price.`)}">Enquire on WhatsApp ↗</a>
<a class="bc-btn outline" target="_blank" rel="noopener" href="${p.instagramUrl}">Watch on Instagram ↗</a><button class="bc-btn outline" id="add">Add to bag</button></div>
<p class="mt-4"><a class="gold" href="shop.html">← Back to collection</a></p></div></div>`;
$('#add').onclick=e=>{Cart.add(p);e.target.textContent='Added ✓'}}
function bag(){const c=Cart.read(),el=$('#bag');
if(!c.length){el.innerHTML='<p class="lead">Your bag is empty for now.</p><a class="bc-btn" href="shop.html">Explore the collection ↗</a>';return}
const total=c.reduce((s,l)=>s+(l.product.price||0)*l.quantity,0),priced=c.some(l=>l.product.price);
el.innerHTML=`<div class="bc-lines">${c.map((l,i)=>`<div class="bc-line"><img src="${l.product.image}" alt=""><div><h3>${l.product.name}</h3><p class="muted">${priceOf(l.product)}</p><div class="bc-qty"><button data-i="${i}" data-d="-1" aria-label="Fewer">−</button>${l.quantity}<button data-i="${i}" data-d="1" aria-label="More">+</button></div></div><strong>${l.product.price?money(l.product.price*l.quantity):''}</strong></div>`).join('')}</div>
${priced?`<div class="bc-total"><span>Total (priced items)</span><strong>${money(total)}</strong></div>`:''}<p class="bc-note text-start ms-0">Prices and availability are confirmed on WhatsApp before any order.</p>
<a class="bc-btn" target="_blank" rel="noopener" href="${wa('Hello BERBIECLOSET, I would like to order: '+c.map(l=>`${l.quantity} x ${l.product.name}`).join(', ')+'. Please confirm availability, sizes and price.')}">Order on WhatsApp ↗</a>`;
el.onclick=e=>{const b=e.target.closest('button[data-i]');if(!b)return;const c=Cart.read(),l=c[b.dataset.i];l.quantity+=+b.dataset.d;if(l.quantity<1)c.splice(b.dataset.i,1);Cart.save(c);bag()}}
document.addEventListener('DOMContentLoaded',()=>{layout();({shop,product,bag})[document.body.dataset.page]?.()});
