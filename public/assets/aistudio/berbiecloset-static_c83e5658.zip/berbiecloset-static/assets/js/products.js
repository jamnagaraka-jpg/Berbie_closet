// Single source of truth for the catalogue. Edit here; every page updates.
const IG='https://www.instagram.com/reel/';
const PRODUCTS=[
{id:1,name:'Everyday Statement Look',category:'Outfits',note:'Outfit available in sizes 10–16',sizes:'10–16',ig:'DdHVCugAzyx'},
{id:2,name:'Printed Jacket',category:'Jackets',note:'Printed jacket',sizes:'10–14',ig:'DdHVf2BAh3R'},
{id:3,name:'Denim Jeans 01',category:'Denim',note:'Jeans',sizes:'10–18',ig:'DdZKMw9AUkE'},
{id:4,name:'Denim Jeans 02',category:'Denim',note:'Jeans',sizes:'10–14',ig:'DdZMQpZAGoJ'},
{id:5,name:'Classic Shirt',category:'Tops',note:'Shirt',sizes:'10–14',ig:'DdZMeI-A-Kt'},
{id:6,name:'Signature Outfit',category:'Outfits',note:'Ready-to-wear look',sizes:'10–14',ig:'DdZMpblAtXp'},
{id:7,name:'Denim Jeans 03',category:'Denim',note:'Jeans',sizes:'10–14',ig:'DdZk4oWAT5m'},
{id:8,name:'Short Set',category:'Co-ords',note:'Two-piece short set',sizes:'10–14',ig:'DdbkHY4hZt5'},
{id:9,name:'Beaded Two-Piece',category:'Co-ords',price:75000,note:'Beautiful beaded two-piece',ig:'Dev2d0DgUAp'}
].map(p=>({...p,image:`assets/img/collection/look-0${p.id}.jpg`,instagramUrl:IG+p.ig+'/'}));
